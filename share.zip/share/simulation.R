###################################################################
###################################################################

#Code for "Additive and interactive pressures of anthropogenic stressors on an insect herbivore."

#Author: Chris Halsch
#Date: December, 1, 2022

#Below you will find the code for the simulation 
#based power analysis followed by code to generate.
#summary figures. 
#See the below table of content:

#Table of contents:
#Lines 23-217: SIMULATION
#Lines 218-420: Figure showing mean difference from truth
#Lines 421-584: Figure showing change in sign
#Lines 585-729: Figure showing power analysis results

###################################################################
###################################################################

##########################################
##########      SIMULATION      ##########
##########################################

library(tidyverse)
library(nimble)
library(caret)

###################################################
##### Generate the sample size for each level #####
###################################################

Melissa_exp_june2022_data <- read_csv("~/Documents/MANUSCRIPTS/pest_temp_inter/share/Melissa_Exp.csv")


n_for_each_trt_level <- Melissa_exp_june2022_data %>% 
  select(ID, Pop, Temperature_trt, Plant_trt, Pest_trt, Day_hatch, weight_pre_pest, Adult_mass) %>% 
  filter(is.na(weight_pre_pest) == F) %>% 
  mutate(surv = ifelse(is.na(Adult_mass) == T, 0, 1),
         weight_pre_pest = as.numeric(substr(weight_pre_pest, 1, nchar(weight_pre_pest)-1)),
         Plant_trt = factor(Plant_trt, levels = c("Astragalus", "Alfalfa")),
         Temperature_trt = factor(Temperature_trt, levels = c("1", "2", "3")),
         Pest_trt = factor(Pest_trt, levels = c("Control", "Low", "High")),
         Pop = factor(Pop),
         combs = paste(Temperature_trt, Plant_trt, Pest_trt, sep = "_")) %>% 
  select(combs) %>% 
  group_by(combs) %>% 
  summarise(n = n()) %>% 
  separate(combs, into = c("Temperature_trt", "Plant_trt", "Pest_trt"), sep = "_")

n_for_each_trt_level <- Melissa_exp_june2022_data %>% 
  select(ID, Pop, Temperature_trt, Plant_trt, Pest_trt, Day_hatch, weight_pre_pest, pupal_weight, Adult_mass, Sex) %>% 
  filter(is.na(Adult_mass) == F) %>% 
  mutate(weight_pre_pest = as.numeric(substr(weight_pre_pest, 1, nchar(weight_pre_pest)-1)),
         Plant_trt = factor(Plant_trt, levels = c("Astragalus", "Alfalfa")),
         Temperature_trt = factor(Temperature_trt, levels = c("1", "2", "3")),
         Pest_trt = factor(Pest_trt, levels = c("Control", "Low", "High")),
         Pop = factor(Pop),
         combs = paste(Temperature_trt, Plant_trt, Pest_trt, sep = "_")) %>% 
  select(combs) %>% 
  group_by(combs) %>% 
  summarise(n = n()) %>% 
  separate(combs, into = c("Temperature_trt", "Plant_trt", "Pest_trt"), sep = "_") 

############################################
##### Make empty dataframe with levels #####
############################################

temp_levels <- c("1", "2", "3")
pest_levels <- c("Control", "Low", "High")
plant_levels <- c("Astragalus", "Alfalfa")

empty_dat <- expand.grid(Temperature_trt = temp_levels, 
                         Pest_trt = pest_levels, 
                         Plant_trt = plant_levels)
#Add dummy levels
empty_dat <- empty_dat %>% 
  mutate(Plant_Temp = paste(Plant_trt, Temperature_trt, sep = "_"),
         Pest_Plant = paste(Pest_trt, Plant_trt, sep = "_"),
         Pest_Temp = paste(Pest_trt, Temperature_trt, sep = "_"),
         Pest_Temp_Plant = paste(Pest_trt, Temperature_trt, Plant_trt, sep = "_"),
         ones1 = 1,
         ones2 = 1,
         ones3 = 1,
         ones4 = 1,
         ones5 = 1,
         ones6 = 1,
         ones7 = 1) %>% 
  left_join(n_for_each_trt_level) %>% 
  spread(key = Temperature_trt, value = ones1, fill = 0) %>% 
  select(-`1`) %>% 
  spread(key = Pest_trt, value = ones2, fill = 0) %>% 
  select(-Control) %>%
  spread(key = Plant_trt, value = ones3, fill = 0) %>% 
  select(-Astragalus) %>%
  spread(key = Plant_Temp, value = ones4, fill = 0) %>% 
  select(-Alfalfa_1, -Astragalus_1, -Astragalus_2, -Astragalus_3) %>% 
  spread(key = Pest_Plant, value = ones5, fill = 0) %>% 
  select(-Control_Alfalfa, -Control_Astragalus, -Low_Astragalus, -High_Astragalus) %>% 
  spread(key = Pest_Temp, value = ones6, fill = 0) %>% 
  select(-High_1, -Low_1, -Control_1, -Control_2, -Control_3) %>% 
  spread(key = Pest_Temp_Plant, value = ones7, fill = 0) %>% 
  select(-Control_1_Alfalfa, -Control_1_Astragalus, -Control_2_Alfalfa, -Control_1_Astragalus, -Control_3_Alfalfa, -Control_3_Astragalus,
         -High_1_Alfalfa, -High_1_Astragalus, -Low_1_Alfalfa, -Low_1_Astragalus, -Low_2_Astragalus, -Low_3_Astragalus,
         -Control_2_Astragalus, -High_2_Astragalus, -High_3_Astragalus)

#####################################
##### Run the power simulation #####
#####################################

nreps <- 1000 #number of runs for each combinations
sample_sizes <- c(10, 20, 50, 100) #sample efforts from for each dataset type

mod_names <- c("add", "two", "three")
l_done_list <- list()

for (i in 1:length(sample_sizes)) {
  
  # generates data frame with n levels
  datlist <- list()
  for (j in 1:nrow(empty_dat)) {
    tempdat <- empty_dat[j,2:ncol(empty_dat)] 
    tempdat <- tempdat[rep(seq_len(nrow(tempdat)), each = sample_sizes[i]), ]
    #if (sample_sizes[i] != 20) { tempdat <- tempdat[rep(seq_len(nrow(tempdat)), each = sample_sizes[i]), ] }
    #if (sample_sizes[i] == 20) { nrep <- empty_dat[[j,1]]
    #tempdat <- tempdat[rep(seq_len(nrow(tempdat)), each = nrep), ] }
    datlist[[j]] <- tempdat
  }
  dat1 <- data.table::rbindlist(datlist)
  
    datlist3 <- list()
    for (k in 1:3) {
      
      datlist2 <- list()
      for (l in 1:nreps) {
        
        #simulates effect sizes. if k=1 there are only additive effects, k=2 brings in two-way interactions, k=3 all types of interactions
        all_effects <- c(runif(6, -5, 5), list(rep(0, 8), runif(8, -5, 5), runif(8, -5, 5))[[k]],  list(rep(0, 4), rep(0, 4), runif(4, -5, 5))[[k]])
        names(all_effects) <- c("EffectWeight", "EffectTemp2", "EffectTemp3", "EffectPestHigh", "EffectPestLow", "EffectAlf",
                                "EffectTemp2_Alf", "EffectTemp3_Alf", "EffectAlf_PestHigh", "EffectAlf_PestLow", "EffectTemp2_PestHigh", "EffectTemp3_PestHigh", "EffectTemp2_PestLow", "EffectTemp3_PestLow",
                                "EffectTemp2_PlantAlf_PestHigh", "EffectTemp3_PlantAlf_PestHigh", "EffectTemp2_PlantAlf_PestLow", "EffectTemp3_PlantAlf_PestLow")
        
        #simulate weight
        iter_dat <- cbind(rgamma(nrow(dat1), 1.8, 15), dat1)
        colnames(iter_dat)[1] <- "Weight"
        iter_dat <- as.matrix(iter_dat)
        
        p <- 1/(1 + exp(-(2.5 + (iter_dat %*% all_effects))))

        iter_dat <- cbind(iter_dat, rbinom(n = nrow(iter_dat), size = 1, prob = p)) #binary data
        #iter_dat <- cbind(iter_dat, rnorm(n = nrow(iter_dat), mean = p, sd = 5)) #continuous data
        colnames(iter_dat)[19] <- "survival"
    
        datlist1 <- list()
        for (m in 1:length(mod_names)) {
          
          if (m == 1) {
            
            model_dat <- data.frame(iter_dat)[,c(1:6, ncol(iter_dat))]
            
            
            glm1 <- glm(survival ~ ., family = "binomial", data = model_dat) #if binary
            #glm1 <- glm(survival ~ ., data = model_dat)  #if continuous
            
            summ <- data.frame(estimates = glm1$coefficients,
                               true = c(2.5, all_effects[1:6]))}
          
          if (m == 2) {
            
            model_dat <- data.frame(iter_dat)[,c(1:14, ncol(iter_dat))]
            
            glm1 <- glm(survival ~ ., family = "binomial", data = model_dat) #if binary
            #glm1 <- glm(survival ~ ., data = model_dat) #if continuous
            
          
            summ <- data.frame(estimates = glm1$coefficients,
            true = c(2.5, all_effects[1:14]))}
          
          if (m == 3) {
          
            model_dat <- data.frame(iter_dat)[,c(1:18, ncol(iter_dat))]
          
            glm1 <- glm(survival ~ ., family = "binomial", data = model_dat) #if binary
            #glm1 <- glm(survival ~ ., data = model_dat) #if continuous
          
            summ <- data.frame(estimates = glm1$coefficients,
            true = c(2.5, all_effects[1:18]))}
          
          #summarize results from run
          summ$miss <- abs(summ$estimates - summ$true)
          summ$p <- coef(summary(glm1))[,4]
          summ$sign <- ifelse(sign(summ$true) == sign(summ$estimates), 1, 0)
          summ$var <- rownames(summ)
          summ$datatype <- k
          summ$mod <- mod_names[m]
          summ$n <- sample_sizes[i]
          summ$rep <- l
          summ$aic <- AIC(glm1)

          datlist1[[m]] <- summ
        }
    
        datlist2[[l]] <- data.table::rbindlist(datlist1)
      }
      
      datlist3[[k]] <- data.table::rbindlist(datlist2)
      print(paste0("N = ", sample_sizes[i], "; ", "datatype = ", k))
    }
    
     l_done_list[[i]] <- data.table::rbindlist(datlist3) 
}

fin <- data.table::rbindlist(l_done_list) #quick combine


###############################################################
########   Figure showing mean difference from truth   ########
###############################################################

heat1 <- fin %>% 
  filter(var != "(Intercept)" & var != "Weight") %>% 
  #filter(var != "EffectWeight") %>% 
  filter(p < 0.05) %>% 
  #filter(p > 0.95) %>% 
  #filter(n == 50) %>% 
  filter(true != 0) %>% 
  group_by(var, mod, datatype, n) %>%
  summarise(mean_miss = mean(miss),
            corr_sign = sum(sign)/length(sign)) %>% 
  mutate(#datatype = factor(datatype, levels = c("1", "2", "3")),
         mod = factor(mod, levels = c("add", "two", "three")),
         #var = factor(var, levels = c("`2`", "`3`", "Low", "High", "Alfalfa", 
         #                             "Low_Alfalfa" , "High_Alfalfa", "Alfalfa_2", "Alfalfa_3", "High_2", "High_3", "Low_2", "Low_3",
          #                            "Low_2_Alfalfa" , "Low_3_Alfalfa", "High_2_Alfalfa", "High_3_Alfalfa")),
         var = factor(var, levels = c("X2", "X3", "Low", "High", "Alfalfa", 
                                      "Low_Alfalfa" , "High_Alfalfa", "Alfalfa_2", "Alfalfa_3", "High_2", "High_3", "Low_2", "Low_3",
                                      "Low_2_Alfalfa" , "Low_3_Alfalfa", "High_2_Alfalfa", "High_3_Alfalfa")),
         und = str_count(var, pattern = "_"),
         int_type = ifelse(und == 0, "add", "two-way"),
         int_type = ifelse(und == 2, "three-way", int_type),
         int_type = factor(int_type, levels = c("add", "two-way", "three-way"))) %>% 
  arrange(mod, datatype, int_type, var) %>% 
  mutate(name = paste(datatype, var, sep = "_"))

labs <- data.frame(var = heat1$var,
                   int_type = heat1$int_type,
                   datatype = heat1$datatype)
labs <- labs %>% distinct()
labs$index <-1:nrow(labs)
labs$index <- factor(labs$index)
heat1 <- left_join(heat1, labs)
#heat1$name <- fct_reorder(heat1$name, heat1$index)
#heat1$mean_miss <- round(heat1$mean_miss, digits = 1)
heat1$mean_miss <- ifelse(heat1$mean_miss > 20, 20, heat1$mean_miss)

colvec <- rev(RColorBrewer::brewer.pal(11, "BrBG"))
#colvec <- paletteer::paletteer_c("ggthemes::Temperature Diverging", 30)

#levels(reorder(factor(Cmpd), desc(lab_y)))
heat1p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 10), aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  #scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("", "", "", "", "", ""), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("Additive\nterms", "Two-way\nterms", "Three-way\nterms"))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("One term\nmodel", "Two term\nmodel", "Three term\nmodel")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

heat2p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 20), aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  #scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("", "", "", "", "", ""), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("Additive\nterms", "Two-way\nterms", "Three-way\nterms"))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("", "", "")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

heat3p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 50), aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  #scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("One-way\npres.", "Two-way\npres.", "Three-way\npres.", "Two-way\npres.", "Three-way\npres.", "Three-way\npres."), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("", "", ""))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("One term\nmodel", "Two term\nmodel", "Three term\nmodel")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )


heat4p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 100), aes(as.numeric(index), factor(mod), fill = mean_miss), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  #scale_fill_gradientn(name = "Mean diff. from truth", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("One-way\npres.", "Two-way\npres.", "Three-way\npres.", "Two-way\npres.", "Three-way\npres.", "Three-way\npres."), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("", "", ""))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("", "", "")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

ggpubr::ggarrange(heat1p, heat2p, heat3p, heat4p, 
                  labels = c("n = 10", "n = 20", "n = 50", "n = 100"),
                  ncol = 2, nrow = 2, widths = c(1.15, 1),
                  legend = "bottom",
                  common.legend = T)


#ggsave("~/Documents/MANUSCRIPTS/pest_temp_inter/sim_miss.png", width = 12, height = 8)


###################################################
########   Figure showing change in sign   ########
###################################################


heat1$corr_sign <- heat1$corr_sign*100
colvec <- RColorBrewer::brewer.pal(11, "BrBG")
#colvec <- rev(paletteer::paletteer_c("ggthemes::Temperature Diverging", 30))

#levels(reorder(factor(Cmpd), desc(lab_y)))
heat1p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 10), aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Percent correct sign", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("", "", "", "", "", ""), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("Additive\nterms", "Two-way\nterms", "Three-way\nterms"))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("One term\nmodel", "Two term\nmodel", "Three term\nmodel")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

heat2p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 20), aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Percent correct sign", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("", "", "", "", "", ""), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("Additive\nterms", "Two-way\nterms", "Three-way\nterms"))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("", "", "")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

heat3p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 50), aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Percent correct sign", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("One-way\npres.", "Two-way\npres.", "Three-way\npres.", "Two-way\npres.", "Three-way\npres.", "Three-way\npres."), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("", "", ""))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("One term\nmodel", "Two term\nmodel", "Three term\nmodel")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )


heat4p <- ggplot(data =  heat1) +
  geom_tile(aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = T) + #builds the heat map
  geom_tile(data = subset(heat1, n == 100), aes(as.numeric(index), factor(mod), fill = corr_sign), color = "black", size = 0.1, alpha = 1, show.legend = F) + #builds the heat map
  geom_segment(aes(x = 5.5, y = 0.5, xend = 5.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 10.5, y = 0.5, xend = 10.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 23.5, y = 0.5, xend = 23.5, yend = 3.5), size = 1, color = "black", linetype = "dotted") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 15.5, y = 0.5, xend = 15.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 31.5, y = 0.5, xend = 31.5, yend = 3.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 1.5, xend = 35.5, yend = 1.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 2.5, xend = 35.5, yend = 2.5), size = 1, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 35.5, y = 0.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 0.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 3.5, xend = 35.5, yend = 3.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  geom_segment(aes(x = 0.5, y = 0.5, xend = 35.5, yend = 0.5,), size = 0.6, color = "black") + #manually make darker lines. Using .5 puts the lines between tiles, not over them.
  scale_fill_gradientn(name = "Percent correct sign", colors = colvec, na.value = "red") + #set color of tiles
  scale_x_continuous(labels = c("One-way\npres.", "Two-way\npres.", "Three-way\npres.", "Two-way\npres.", "Three-way\npres.", "Three-way\npres."), breaks = c(3, 8, 13, 20, 28, 34),
                     sec.axis = sec_axis(~., breaks = c(8, 24, 34), labels = c("", "", ""))) +
  #manually add labels. I played with the spacing alot.
  scale_y_discrete(labels = c("", "", "")) +
  #coord_fixed(3) + #adjusts the shape of the tiles
  theme_classic() +
  theme(axis.ticks = element_blank(),
        axis.text.x.bottom = element_text(face="bold", color="black", size=10), 
        axis.text.x.top = element_text(face="bold", color="black", size=10), 
        axis.text.y = element_text(face="bold", color="black", size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        legend.text = element_text(face="bold", color="black", size=10),
        legend.title = element_text(face="bold", color="black", size=10),
        legend.position = "bottom",
        legend.direction="horizontal",
        legend.key.width=unit(0.9,"cm"),
        panel.border = element_blank(),
        axis.line = element_blank()
  )

ggpubr::ggarrange(heat1p, heat2p, heat3p, heat4p, 
                  labels = c("n = 10", "n = 20", "n = 50", "n = 100"),
                  ncol = 2, nrow = 2, widths = c(1.15, 1),
                  legend = "bottom",
                  common.legend = T)

#ggsave("~/Documents/MANUSCRIPTS/pest_temp_inter/sim_sign.png", width = 12, height = 8)


###########################################################
########   Figure showing power analysis results   ########
###########################################################

new_plot <- fin %>% 
  filter(var != "Weight" & var != "(Intercept)") %>% 
  filter(true != 0) %>% 
  filter(p < 0.25) %>%
  filter(n == 20) %>% 
  filter(mod == "three") %>% 
  mutate(p_round = plyr::round_any(p, 0.01),
         und = str_count(var, pattern = "_"),
         int_type = ifelse(und == 0, "add", "two-way"),
         int_type = ifelse(und == 2, "three-way", int_type),
         int_type = factor(int_type, levels = c("add", "two-way", "three-way")),
         true = abs(true)) %>% 
  filter(int_type == "add") %>% 
  #filter(int_type == "two-way") %>% 
  #filter(int_type == "three-way") %>% 
  group_by(var, p_round, n) %>% 
  summarise(mean_t = mean(true),
            t_lq = quantile(true, 0.2),
            t_uq = quantile(true, 0.8))


p1 <- ggplot(data = new_plot) +
  #geom_hline(aes(yintercept = 0.05), linetype = "dashed", color = "black") +
  #geom_ribbon(aes(y = p_round, xmin = t_lq, xmax= t_uq, fill = factor(n)), alpha=0.5) +
  geom_path(aes(mean_t, p_round, color = factor(var)), size = 1.75) +
  labs(color = "Sample Size") +
  #labs(color = "Effect Type") +
  scale_color_manual(values = wesanderson::wes_palette("IsleofDogs1")) +
  #scale_color_manual(values = cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")) +
  #scale_color_manual(values = wesanderson::wes_palette("GrandBudapest1")) +
  scale_x_continuous(limits = c(0, 5)) +
  theme_classic() +
  theme(axis.title = element_blank(),
        axis.text = element_text(size = 15, color = "black"),
        legend.title = element_blank(),
        legend.text = element_text(size = 15, color = "black"),
        legend.position = c(0.75, 0.75), 
        panel.grid.major = element_line(size = 0.5, color = "gray50", linetype = "dashed"),
        plot.margin = margin(1, 0, 0, 0, "cm")
        )

new_plot <- fin %>% 
  filter(var != "Weight" & var != "(Intercept)") %>% 
  filter(true != 0) %>% 
  filter(p < 0.25) %>%
  filter(n == 20) %>% 
  filter(mod == "three") %>% 
  mutate(p_round = plyr::round_any(p, 0.01),
         und = str_count(var, pattern = "_"),
         int_type = ifelse(und == 0, "add", "two-way"),
         int_type = ifelse(und == 2, "three-way", int_type),
         int_type = factor(int_type, levels = c("add", "two-way", "three-way")),
         true = abs(true)) %>% 
  #filter(int_type == "add") %>% 
  filter(int_type == "two-way") %>% 
  #filter(int_type == "three-way") %>% 
  group_by(var, p_round, n) %>% 
  summarise(mean_t = mean(true),
            t_lq = quantile(true, 0.2),
            t_uq = quantile(true, 0.8))


p2 <- ggplot(data = new_plot) +
  #geom_hline(aes(yintercept = 0.05), linetype = "dashed", color = "black") +
  #geom_ribbon(aes(y = p_round, xmin = t_lq, xmax= t_uq, fill = factor(n)), alpha=0.5) +
  geom_path(aes(mean_t, p_round, color = factor(var)), size = 1.75) +
  labs(color = "Sample Size") +
  #labs(color = "Effect Type") +
  #scale_color_manual(values = wesanderson::wes_palette("IsleofDogs1")) +
  scale_color_manual(values = cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")) +
  #scale_color_manual(values = wesanderson::wes_palette("GrandBudapest1")) +
  scale_x_continuous(limits = c(0, 5)) +
  theme_classic() +
  theme(axis.title = element_blank(),
        axis.text = element_text(size = 15, color = "black"),
        legend.title = element_blank(),
        legend.text = element_text(size = 15, color = "black"),
        legend.position = c(0.75, 0.75), 
        panel.grid.major = element_line(size = 0.5, color = "gray50", linetype = "dashed"),
        plot.margin = margin(1, 0, 0, 0, "cm")
  )

new_plot <- fin %>% 
  filter(var != "Weight" & var != "(Intercept)") %>% 
  filter(true != 0) %>% 
  filter(p < 0.25) %>%
  filter(n == 20) %>% 
  filter(mod == "three") %>% 
  mutate(p_round = plyr::round_any(p, 0.01),
         und = str_count(var, pattern = "_"),
         int_type = ifelse(und == 0, "add", "two-way"),
         int_type = ifelse(und == 2, "three-way", int_type),
         int_type = factor(int_type, levels = c("add", "two-way", "three-way")),
         true = abs(true)) %>% 
  #filter(int_type == "add") %>% 
  #filter(int_type == "two-way") %>% 
  filter(int_type == "three-way") %>% 
  group_by(var, p_round, n) %>% 
  summarise(mean_t = mean(true),
            t_lq = quantile(true, 0.2),
            t_uq = quantile(true, 0.8))


p3 <- ggplot(data = new_plot) +
  #geom_hline(aes(yintercept = 0.05), linetype = "dashed", color = "black") +
  #geom_ribbon(aes(y = p_round, xmin = t_lq, xmax= t_uq, fill = factor(n)), alpha=0.5) +
  geom_path(aes(mean_t, p_round, color = factor(var)), size = 1.75) +
  labs(color = "Sample Size") +
  #labs(color = "Effect Type") +
  #scale_color_manual(values = wesanderson::wes_palette("IsleofDogs1")) +
  #scale_color_manual(values = cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")) +
  scale_color_manual(values = wesanderson::wes_palette("GrandBudapest1")) +
  scale_x_continuous(limits = c(0, 5)) +
  theme_classic() +
  theme(axis.title = element_blank(),
        axis.text = element_text(size = 15, color = "black"),
        legend.title = element_blank(),
        legend.text = element_text(size = 15, color = "black"),
        legend.position = c(0.75, 0.75), 
        panel.grid.major = element_line(size = 0.5, color = "gray50", linetype = "dashed"),
        plot.margin = margin(1, 0, 0, 0, "cm")
  )


library(ggpubr)
library(grid)

com <- ggarrange(p1, p2, p3,
         ncol = 3, nrow = 1,
        labels = c("add", "two-way", "three-way"), font.label = list(size = 20))

com <- annotate_figure(com, left = textGrob("p-value", rot = 90, vjust = 0.5, gp = gpar(cex = 2)),
                bottom = textGrob("Simulated effect size", gp = gpar(cex = 2)))
com
#png(file="~/Documents/MANUSCRIPTS/pest_temp_inter/power_mass.png", width=1200, height=1000)
#com
#dev.off()



#ggsave("~/Desktop/fig.png", device = "png", height = 10, width = 12, dpi = 300)



