
###################################################################
###################################################################

#Code for "Additive and interactive pressures of anthropogenic stressors on an insect herbivore."

#Author: Chris Halsch
#Date: December, 1, 2022

#Below you will find the code for the analysis of the survival, 
#adult mass, and larval development time Bayesian models.
#Each block can be run independently. 
#See the below table of content:

#Table of contents:
#Lines 22-125: SURVIVAL ANOVA
#Lines 128-245: Creation of map for figure 1

###################################################################
###################################################################

##############################################
##########      SURVIVAL ANOVA      ##########
##############################################

library(tidyverse)
library(ggpattern)
library(wesanderson)
library(ggpubr)

#Import experiment data
Melissa_exp_june2022_data <- read_csv("~/Documents/MANUSCRIPTS/pest_temp_inter/share/Melissa_Exp.csv")

surv_dat <- Melissa_exp_june2022_data %>% 
  select(ID, Pop, Temperature_trt, Plant_trt, Pest_trt, Day_hatch, weight_pre_pest, Adult_mass) %>% 
  filter(is.na(weight_pre_pest) == F) %>% 
  mutate(surv = ifelse(is.na(Adult_mass) == T, 0, 1),
         weight_pre_pest = scale(as.numeric(substr(weight_pre_pest, 1, nchar(weight_pre_pest)-1)))[,1],
         Plant_trt = factor(Plant_trt, levels = c("Astragalus", "Alfalfa")),
         Temperature_trt = factor(Temperature_trt, levels = c("1", "2", "3")),
         Pest_trt = factor(Pest_trt, levels = c("Control", "Low", "High")),
         Pop = as.numeric(factor(Pop)),
         Pop = ifelse(Pop == 2, 0, 1),
         comb = paste(Plant_trt, Temperature_trt, Pest_trt, sep = "_")) %>% 
  select(-Adult_mass) %>% 
  na.omit() %>% 
  mutate(Plant_Temp = paste(Plant_trt, Temperature_trt, sep = "_"),
         Pest_Plant = paste(Pest_trt, Plant_trt, sep = "_"),
         Pest_Temp = paste(Pest_trt, Temperature_trt, sep = "_"),
         Pest_Temp_Plant = paste(Pest_trt, Temperature_trt, Plant_trt, sep = "_"),
         ones1 = 1,
         ones2 = 1,
         ones3 = 1,
         ones4 = 1,
         ones5 = 1,
         ones6 = 1,
         ones7 = 1) %>% 
  spread(key = Temperature_trt, value = ones1, fill = 0) %>% 
  select(-`1`) %>% 
  spread(key = Pest_trt, value = ones2, fill = 0) %>% 
  select(-Control) %>%
  spread(key = Plant_trt, value = ones3, fill = 0) %>% 
  select(-Astragalus) %>%
  spread(key = Plant_Temp, value = ones4, fill = 0) %>% 
  select(-Alfalfa_1, -Astragalus_1, -Astragalus_2, -Astragalus_3) %>% 
  spread(key = Pest_Plant, value = ones5, fill = 0) %>% 
  select(-Control_Alfalfa, -Control_Astragalus, -Low_Astragalus, -High_Astragalus) %>% 
  spread(key = Pest_Temp, value = ones6, fill = 0) %>% 
  select(-High_1, -Low_1, -Control_1, -Control_2, -Control_3) %>% 
  spread(key = Pest_Temp_Plant, value = ones7, fill = 0) %>% 
  select(-Control_1_Alfalfa, -Control_1_Astragalus, -Control_2_Alfalfa, -Control_1_Astragalus, -Control_3_Alfalfa, -Control_3_Astragalus,
         -High_1_Alfalfa, -High_1_Astragalus, -Low_1_Alfalfa, -Low_1_Astragalus, -Low_2_Astragalus, -Low_3_Astragalus,
         -Control_2_Astragalus, -High_2_Astragalus, -High_3_Astragalus)


preds <- surv_dat[,c(2,4,7:23)]

mod_data <- list(surv = surv_dat$surv,
                 X1 = as.matrix(preds),
                 Ncovars = ncol(preds),
                 N = length(surv_dat$surv))

model <- "model {
          
          for (i in 1:N) { 
          
          #Lowest level. Here you can see the three multiple regressions, which creates the SEM framework. Each beta coefficient is nested with [species, site],
          #which results in a different estimate for each species and site combination.
          
              surv[i] ~ dbern(p[i])
              logit(p[i]) <- A + B %*% X1[i,]

          }
          
          #Set hyper priors for butterfly model
          for (j in 1:Ncovars) {

              B[j] ~ dnorm(0, 0.7142857)
  
            }
          
        A ~ dnorm(0, 0.7142857)

}	
"

writeLines(model, con="model.txt")

params <- c("A", "B")

mod <- jagsUI::jags(data = mod_data,
                    n.adapt = 1000,
                    n.burnin = 1000,
                    n.iter = 10000,
                    n.chains = 4,
                    modules = "glm",
                    parallel = T,
                    model.file = "model.txt",
                    parameters.to.save = params,
                    verbose = TRUE)

summ <- data.frame(mod$summary)
summ$var <- c("int", colnames(preds), "dev")

#write.csv(summ, "~/Documents/MANUSCRIPTS/pest_temp_inter/surv_table.csv", row.names = F)


##################################################
##########      MASS AND LDT ANOVA      ##########
##################################################

library(tidyverse)
library(ggpattern)
library(wesanderson)
library(ggpubr)

#Import experiment data
Melissa_exp_june2022_data <- read_csv("~/Documents/MANUSCRIPTS/pest_temp_inter/share/Melissa_Exp.csv")

mass_dat1 <- Melissa_exp_june2022_data %>% 
  select(ID, Pop, Temperature_trt, Plant_trt, Pest_trt, Day_hatch, weight_pre_pest, pupal_weight, Adult_mass, Sex, Pup_date) %>% 
  filter(is.na(Adult_mass) == F) %>% 
  filter(Adult_mass < 0.05) %>% 
  mutate(weight_pre_pest = as.numeric(substr(weight_pre_pest, 1, nchar(weight_pre_pest)-1)),
         Plant_trt = factor(Plant_trt, levels = c("Astragalus", "Alfalfa")),
         Temperature_trt = factor(Temperature_trt, levels = c("1", "2", "3")),
         Pest_trt = factor(Pest_trt, levels = c("Control", "Low", "High")),
         Pop = factor(Pop),
         Day_hatch = as.Date(Day_hatch, format = "%m/%d"),
         Pup_date = as.Date(Pup_date, format = "%m/%d"),
         LDT = as.numeric(Pup_date - Day_hatch)) %>% 
  mutate(Plant_Temp = paste(Plant_trt, Temperature_trt, sep = "_"),
         Pest_Plant = paste(Pest_trt, Plant_trt, sep = "_"),
         Pest_Temp = paste(Pest_trt, Temperature_trt, sep = "_"),
         Pest_Temp_Plant = paste(Pest_trt, Temperature_trt, Plant_trt, sep = "_"),
         Sex = ifelse(Sex == "M", 1, 0),
         Pop = ifelse(Pop == 2, 0, 1),
         ones1 = 1,
         ones2 = 1,
         ones3 = 1,
         ones4 = 1,
         ones5 = 1,
         ones6 = 1,
         ones7 = 1) %>% 
  spread(key = Temperature_trt, value = ones1, fill = 0) %>% 
  select(-`1`) %>% 
  spread(key = Pest_trt, value = ones2, fill = 0) %>% 
  select(-Control) %>%
  spread(key = Plant_trt, value = ones3, fill = 0) %>% 
  select(-Astragalus) %>%
  spread(key = Plant_Temp, value = ones4, fill = 0) %>% 
  select(-Alfalfa_1, -Astragalus_1, -Astragalus_2, -Astragalus_3) %>% 
  spread(key = Pest_Plant, value = ones5, fill = 0) %>% 
  select(-Control_Alfalfa, -Control_Astragalus, -Low_Astragalus, -High_Astragalus) %>% 
  spread(key = Pest_Temp, value = ones6, fill = 0) %>% 
  select(-High_1, -Low_1, -Control_1, -Control_2, -Control_3) %>% 
  spread(key = Pest_Temp_Plant, value = ones7, fill = 0) %>% 
  select(-Control_1_Alfalfa, -Control_1_Astragalus, -Control_2_Alfalfa, -Control_1_Astragalus, -Control_3_Alfalfa, -Control_3_Astragalus,
         -High_1_Alfalfa, -High_1_Astragalus, -Low_1_Alfalfa, -Low_1_Astragalus, -Low_2_Astragalus, -Low_3_Astragalus,
         -Control_2_Astragalus, -High_2_Astragalus, -High_3_Astragalus) %>% 
  na.omit()


#MASS Predictors
preds <- mass_dat1[,c(2,4,7,9:25)]

#LDT predictors
#preds <- mass_dat1[,c(2,4,7,10:25)]

mod_data <- list(mass = mass_dat1$Adult_mass * 1000,
                 #LDT = mass_dat1$LDT,
                 X1 = as.matrix(preds),
                 Ncovars = ncol(preds),
                 N = length(mass_dat1$Adult_mass))

model <- "model {
          
          for (i in 1:N) { 
          
          #Lowest level. Here you can see the three multiple regressions, which creates the SEM framework. Each beta coefficient is nested with [species, site],
          #which results in a different estimate for each species and site combination.
              
              #MASS likelihood
              mass[i] ~ dnorm(mu[i], sig)
              mu[i] <- A + B %*% X1[i,]
              
              #LDT likelihood
              #LDT[i] ~ dpois(mu[i])
              #log(mu[i]) <- A + B %*% X1[i,]

          }
          
          #Set hyper priors for butterfly model
          for (j in 1:Ncovars) {

              B[j] ~ dnorm(0, 0.01)
  
            }
          
        A ~ dnorm(0, 0.01)
        sig ~ dgamma(2, 0.01)

}	
"

writeLines(model, con="model.txt")

params <- c("A", "B")

mod <- jagsUI::jags(data = mod_data,
                    n.adapt = 1000,
                    n.burnin = 1000,
                    n.iter = 10000,
                    n.chains = 4,
                    modules = "glm",
                    parallel = T,
                    model.file = "model.txt",
                    parameters.to.save = params,
                    verbose = TRUE)

summ <- data.frame(mod$summary)
summ$var <- c("int", colnames(preds), "dev")

#write.csv(summ, "~/Documents/MANUSCRIPTS/pest_temp_inter/mass_table.csv", row.names = F)
#write.csv(summ, "~/Documents/MANUSCRIPTS/pest_temp_inter/LDT_table.csv", row.names = F)

